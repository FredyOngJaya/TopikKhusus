var main_container = document.querySelector("div#container");

var CategoryList = React.createClass({displayName: 'CategoryList',
    loadData: function () {
        $.ajax({
            url: this.props.url,
            dataType: 'json',
            success: function (data) {
                this.setState({categories: data.results});
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(xhr);
                console.log(status);
                console.log(err);
            }.bind(this)
        });
    },
	handleListClick: function (item, section) {
		this.props.listSelected(item, section);
	},
	getInitialState: function () {
		return {categories: []};
	},
	componentDidMount: function () {
		this.loadData();
	},
	render: function () {
		var items = this.state.categories.map(function (c) {
			var btnType   = this.props.active === c["list_name_encoded"]? "btn-primary": "btn-default",
				classList = "btn " + btnType;

			return (
					React.createElement("a", {href:  "#" + c["list_name_encoded"], 
					   className: classList, 
					   key: c["list_name_encoded"], 
					   ref: c["list_name_encoded"], 
					   onClick: this.handleListClick.bind(this, c["list_name_encoded"], c["display_name"])}, 
						c["display_name"]
					)
			);
		}.bind(this));

		return (
			React.createElement("div", {className: "col-md-4"}, 
				React.createElement("div", {className: "btn-group-vertical", id: "catlist"}, 
					items
				)
			)
		);
	}
});

var CategoryContent = React.createClass({displayName: 'CategoryContent',
    loadData: function (item) {
    	var full_url = "./data/best-sellers/" + item + ".json";

        $.ajax({
            url: full_url,
            dataType: 'json',
            success: function (data) {
                this.setState({
                	date: data.results.bestsellers_date,
                	books: data.results.books
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(xhr);
                console.log(status);
                console.log(err);
            }.bind(this)
        });
    },
	getInitialState: function () {
		return {date: "", books: []};
	},
	componentWillReceiveProps: function (next_prop) {
		if (next_prop.item) {
			this.loadData(next_prop.item);
		}
	},
	render: function () {
		var book_rows = this.state.books.map(function (book, i) {
			var row_key = "book-" + i;

			return (
				React.createElement("tr", {key: row_key}, 
					React.createElement("td", null, book.title), 
					React.createElement("td", null, book.author), 
					React.createElement("td", null, book.primary_isbn10), 
					React.createElement("td", null, 
						React.createElement("a", {href: book.amazon_product_url}, 
							React.createElement("i", {className: "mdi-action-shopping-basket"})
						)
					)
				)
			);
		});

		var caption = "New York Times Best Seller List";
		if (this.props.section && this.state.date) {
			caption = "New York Times Best Seller ({0}) from {1}".format(this.props.section, this.state.date);
		}

		return (
			React.createElement("div", {className: "col-md-8"}, 
				React.createElement("table", {className: "table table-striped table-hover"}, 
					React.createElement("caption", null, caption), 
					React.createElement("thead", null, 
						React.createElement("tr", null, 
							React.createElement("th", null, "Title"), 
							React.createElement("th", null, "Author"), 
							React.createElement("th", null, "ISBN"), 
							React.createElement("th", null, "Action")
						)
					), 
					React.createElement("tbody", null, 
						book_rows
					)
				)
			)
		);
	}
});

var Category = React.createClass({displayName: 'Category',
	getInitialState: function () {
		return {item: []};
	},
	handleListSelected: function (data, sect) {
		this.setState({item: data, section: sect, active: data});
	},
	render: function () {
		var data = this.state.item;
		var sect = this.state.section;

		return (
			React.createElement("div", {className: "row"}, 
				React.createElement(CategoryList, {url: this.props.url, 
							  active: this.state.active, 
							  listSelected: this.handleListSelected}), 
				React.createElement(CategoryContent, {item: data, section: sect})
			)
		);
	}
});

React.render(React.createElement(Category, {url: "./data/all-names.json"}), main_container);