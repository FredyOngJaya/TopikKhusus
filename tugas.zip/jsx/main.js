var main_container = document.querySelector("div#container");

var CategoryList = React.createClass({
    loadData: function () {
        $.ajax({
            url: this.props.url,
            dataType: 'json',
            success: function (data) {
                this.setState({categories: data.results});
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(xhr);
                console.log(status);
                console.log(err);
            }.bind(this)
        });
    },
	handleListClick: function (item, section) {
		this.props.listSelected(item, section);
	},
	getInitialState: function () {
		return {categories: []};
	},
	componentDidMount: function () {
		this.loadData();
	},
	render: function () {
		var items = this.state.categories.map(function (c) {
			var btnType   = this.props.active === c["list_name_encoded"]? "btn-primary": "btn-default",
				classList = "btn " + btnType;

			return (
					<a href={ "#" + c["list_name_encoded"] }
					   className={classList}
					   key={c["list_name_encoded"]}
					   ref={c["list_name_encoded"]}
					   onClick={this.handleListClick.bind(this, c["list_name_encoded"], c["display_name"])}>
						{c["display_name"]}
					</a>
			);
		}.bind(this));

		return (
			<div className="col-md-4">
				<div className="btn-group-vertical" id="catlist">
					{items}
				</div>
			</div>
		);
	}
});

var CategoryContent = React.createClass({
    loadData: function (item) {
    	var full_url = "./data/best-sellers/" + item + ".json";

        $.ajax({
            url: full_url,
            dataType: 'json',
            success: function (data) {
                this.setState({
                	date: data.results.bestsellers_date,
                	books: data.results.books
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(xhr);
                console.log(status);
                console.log(err);
            }.bind(this)
        });
    },
	getInitialState: function () {
		return {date: "", books: []};
	},
	componentWillReceiveProps: function (next_prop) {
		if (next_prop.item) {
			this.loadData(next_prop.item);
		}
	},
	render: function () {
		var book_rows = this.state.books.map(function (book, i) {
			var row_key = "book-" + i;

			return (
				<tr key={row_key}>
					<td>{book.title}</td>
					<td>{book.author}</td>
					<td>{book.primary_isbn10}</td>
					<td>
						<a href={book.amazon_product_url}>
							<i className="mdi-action-shopping-basket"></i>
						</a>
					</td>
				</tr>
			);
		});

		var caption = "New York Times Best Seller List";
		if (this.props.section && this.state.date) {
			caption = "New York Times Best Seller ({0}) from {1}".format(this.props.section, this.state.date);
		}

		return (
			<div className="col-md-8">
				<table className="table table-striped table-hover">
					<caption>{caption}</caption>
					<thead>
						<tr>
							<th>Title</th>
							<th>Author</th>
							<th>ISBN</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						{book_rows}
					</tbody>
				</table>
			</div>
		);
	}
});

var Category = React.createClass({
	getInitialState: function () {
		return {item: []};
	},
	handleListSelected: function (data, sect) {
		this.setState({item: data, section: sect, active: data});
	},
	render: function () {
		var data = this.state.item;
		var sect = this.state.section;

		return (
			<div className="row">
				<CategoryList url={this.props.url} 
							  active={this.state.active}
							  listSelected={this.handleListSelected} />
				<CategoryContent item={data} section={sect} />
			</div>
		);
	}
});

React.render(<Category url="./data/all-names.json" />, main_container);